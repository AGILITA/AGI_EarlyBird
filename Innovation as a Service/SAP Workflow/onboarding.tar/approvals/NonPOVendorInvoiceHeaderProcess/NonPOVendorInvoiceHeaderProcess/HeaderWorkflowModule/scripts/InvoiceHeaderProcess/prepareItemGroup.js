var itemgroupResponse = $.context.internal.itemGroupResponse.Result[0].ItemGroupList;
var InvoiceHeader = $.context.invoiceDetails.headerDetail;
var InvoiceItems = $.context.invoiceDetails.items;
var counter = 0;
var items1 = $.context.approval.itemGroups;
var j = 1;
var newArr = [];
for (var i = 0, len = InvoiceItems.length, p; i < len; i++) {
p = InvoiceItems[i];
//Preparing cost object dyamically as per business rules mentioned itemgroup
 $.context.invoiceDetails.items[i].costObject = "";
    
    for( var j = 0; j < itemgroupResponse.length; j++) {
        var costField = itemgroupResponse[j].FieldName;
        if(typeof $.context.invoiceDetails.items[i].costObject === "undefined"){
            $.context.invoiceDetails.items[i].costObject = p[costField];
        }else{
            $.context.invoiceDetails.items[i].costObject = $.context.invoiceDetails.items[i].costObject + p[costField];
        }
        
    }
}
//Calculating Item group no. into the invoice item details as per costobjects. 
var InvoiceItems = $.context.invoiceDetails.items;
for (var i = 0, len = InvoiceItems.length, p; i < len; i++) { 
    p = InvoiceItems[i];
    if(newArr[p.costObject]==undefined){

        newArr[p.costObject] = { 
                                    "itemGroupNo": counter,
                                    "companyCode": InvoiceHeader.companyCode,
                                    "currencyKey": InvoiceHeader.currencyKey,
                                    "exchangeRate": InvoiceHeader.exchangeRate,
                                    "paymentTerm": InvoiceHeader.paymentTerm,
                                    "paymentMethod": InvoiceHeader.paymentMethod,
                                    "costCenter": p.costCenter,
                                    "internalOrder": p.internalOrder,
                                    "profitCenter": p.profitCenter,
                                    "businessArea": p.businessArea,
                                    "gLAccount": p.gLAccount,
                                    "plant": p.plant,
                                    "releaseGroup": p.releaseGroup,
                                    "amount": 0,
                                    "costObject": p.costObject  
                                };

                                counter = counter + 1;
                            }
    newArr[p.costObject].amount += p.amount;
    $.context.invoiceDetails.items[i].itemGroupNo = newArr[p.costObject].itemGroupNo;
    
}

//Prepared Itegroup list as per current cost object
$.context.approval.itemGroups = newArr;

$.context.internal.itemGroupCount = counter;

$.context.internal.itemGroupCounter = 0;
