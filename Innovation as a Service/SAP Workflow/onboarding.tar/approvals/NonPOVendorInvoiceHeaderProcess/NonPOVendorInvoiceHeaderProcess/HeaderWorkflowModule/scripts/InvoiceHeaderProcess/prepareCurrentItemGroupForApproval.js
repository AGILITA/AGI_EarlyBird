var history = [];
//Before sedning approval, looking for if any past history is exist or not as per the running costobject in the itemgroup iteration.
if (typeof $.context.rework !== 'undefined') {
    for (var j = 0; j < $.context.rework.itemGroups.length; j++) {
        var currentCostObject = $.context.approval.currentItemGroup.costObject;
        var itemCostObject = $.context.rework.itemGroups[j].costObject;
        if (currentCostObject === itemCostObject) {
            if (typeof $.context.rework.itemGroups[j].history !== 'undefined') {
                for (var a = 0; a < $.context.rework.itemGroups[j].history.length; a++) {

                    history.push($.context.rework.itemGroups[j].history[a]);
                }
            }
            break;
        }
    }
}


//Preparing approval history action of intiator. He can either Invoice request or resubmit the invoice
var decision, actionText;
if (typeof $.context.rework === 'undefined') {
    actionText = "Invoice Requested";
} else {
    actionText = "Invoice Re-submitted";
}

//Preparing current itemgroup based approval history
decision = {
    "userId": $.context.invoiceDetails.headerDetail.initiator,
    "role": "Initiator",
    "action": "Invoice Request",
    "comments": $.context.invoiceDetails.headerDetail.initiatorComments,
    "actionText": actionText
};
history.push(decision);

//Preparing item workflow intital context.
var approvalContext = {
    "invoiceDetails": $.context.invoiceDetails,
    "headerInstanceId": $.info.workflowInstanceId,
    "currentItemGroup": $.context.approval.currentItemGroup,
    "history": history
};
var result = $.context.internal.processVariantResponse.Result[0];

//Preparing payload to start item workflow 
$.context.internal.startItemApprovalPayload = {
    "definitionId": result.ProcessVariantDetail.ProcessVariantId,
    "context": approvalContext
};

//preparing loopcounter for next itemgroup iteration
var loopCount = $.context.internal.itemGroupCounter;
loopCount = loopCount + 1;
$.context.internal.itemGroupCounter = loopCount;

//Checking if next item group exist or not
$.context.internal.isMoreItemGroup = true;
if ($.context.internal.itemGroupCounter == $.context.internal.itemGroupCount) {
    $.context.internal.isMoreItemGroup = false;
    $.context.internal.itemGroupCounter = 0;
}
