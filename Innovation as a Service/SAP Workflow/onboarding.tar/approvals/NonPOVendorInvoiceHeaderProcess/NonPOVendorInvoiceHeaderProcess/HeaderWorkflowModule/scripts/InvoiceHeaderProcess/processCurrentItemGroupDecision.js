$.context.internal.isMoreItemGroup = true;

var loopCount = $.context.internal.itemGroupCounter;
loopCount = loopCount + 1;
$.context.internal.itemGroupCounter = loopCount;

if ($.context.internal.itemGroupCounter === $.context.internal.itemGroupCount) {
    $.context.internal.isMoreItemGroup = false;
}

var itemGroupNo = $.context.approvalMsgResponse.currentItemGroup.itemGroupNo;
var i = itemGroupNo;


$.context.approval.itemGroups[i].history = [];
//Capturing itegroup respective history into the context from iteworkflow response
var rework = $.context.rework;
if (i >= 0) {
    if (typeof rework !== 'undefined') {
        if ($.context.approval.currentItemGroup.costObject === rework.itemGroups[i].costObject) {
            for (var j = 0; j < rework.itemGroups[i].history.length; j++) {

                $.context.approval.itemGroups[i].history = rework.itemGroups[i].history;
            }
        }
    }

    for (var k = $.context.approvalMsgResponse.history.length - 1; k >= 0; k--) {
        if ($.context.approvalMsgResponse.history[k].action == "Invoice Request") {
            break;
        }
    }

    for (var a = k; a < $.context.approvalMsgResponse.history.length; a++) {
        $.context.approval.itemGroups[i].history.push($.context.approvalMsgResponse.history[a]);
    }
    
}

