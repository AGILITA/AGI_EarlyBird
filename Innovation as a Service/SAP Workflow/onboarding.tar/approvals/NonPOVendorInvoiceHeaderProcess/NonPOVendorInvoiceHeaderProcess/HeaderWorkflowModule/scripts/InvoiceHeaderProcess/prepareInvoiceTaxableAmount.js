$.context.internal.isERPValidated = true;

//If tax calculation failed, Preparing rework reason for initiator's rework task.
$.context.internal.reworkReason = [];
if (!$.context.internal.isNonTaxableInvoice && typeof $.context.internal.taxCalculationResponse.return !== 'undefined') {
    var result = $.context.internal.taxCalculationResponse.return;
    if (typeof result[0] !== 'undefined') {
        for (var i = 0; i < result.length; i++) {
            if (result[i].type == "E") {
                $.context.internal.isERPValidated = false;
                if (i > 0) {
                    if ($.context.internal.validation.validationMessage === "") {
                        $.context.internal.validation.validationMessage = result[i].message + ". ";
                    } else {
                        $.context.internal.validation.validationMessage = $.context.internal.validation.validationMessage + '\n';
                        $.context.internal.validation.validationMessage = $.context.internal.validation.validationMessage + result[i].message + ". ";
                    }
                    var msg = {
                        "message": result[i].message
                    }

                    $.context.internal.reworkReason.push(msg);
                }
            }
        }
    } else {
        if (result.type === "E") {
            $.context.internal.isERPValidated = false;

        }
    }
}


//Prepare Invoice Validation Payload for SAP ERP
var accountPayable = [
    {
        "itemAccountNumber": 1,
        "vendorNo": $.context.invoiceDetails.headerDetail.vendorNumber,
        "itemText": $.context.invoiceDetails.headerDetail.text,
        "paymentTerm": $.context.invoiceDetails.headerDetail.paymentTerm,
        "paymentMethod": $.context.invoiceDetails.headerDetail.paymentMethod,
        "dueDay1": $.context.invoiceDetails.paymentTerms[0].days,
        "dueDay2": $.context.invoiceDetails.paymentTerms[1].days,
        "netTerms": $.context.invoiceDetails.paymentTerms[2].days,
        "discount1": $.context.invoiceDetails.paymentTerms[0].percentageAmount,
        "dicsount2": $.context.invoiceDetails.paymentTerms[1].percentageAmount
    }
];

var customerCD = [
    {
        "name": $.context.invoiceDetails.headerDetail.oneTimeVendorName,
        "city": $.context.invoiceDetails.headerDetail.oneTimeVendorCity,
        "country": $.context.invoiceDetails.headerDetail.oneTimeVendorCountry
    }
]
if ($.context.internal.isNonTaxableInvoice) {
    //Check invoice payload If invoice is non-taxable invoice
    var accountGl_tab = [], currencyAmount_tab = [];
    var currencyAmount = {
        "itemAccountNumber": 1,
        "currency": $.context.invoiceDetails.headerDetail.currency,
        "amount": $.context.invoiceDetails.headerDetail.invoiceAmount * -1,
        "baseAmount": "0",
        "exchangeRate": $.context.invoiceDetails.headerDetail.exchangeRate
    };
    currencyAmount_tab.push(currencyAmount);
    var items = $.context.invoiceDetails.items;
    for (var i = 0; i < items.length; i++) {
        var itemNo = (items[i].itemNumber + 1);

        //Prepare AccountGL    
        var accountGL = {
            "itemAccountNumber": itemNo.toString(),
            "glAccountNo": items[i].glAccount,
            "itemText": items[i].itemText,
            "acctType": "S",
            "companyCode": $.context.invoiceDetails.headerDetail.companyCode,
            "taxCode": items[i].taxCode,
            "vendorNo": $.context.invoiceDetails.headerDetail.vendorNumber,
            "profitCenter": items[i].profitCenter,
            "costCenter": items[i].costCenter,
            "businessArea": items[i].businessArea,
            "plant": items[i].plant,
            "internalOrder": items[i].internalOrder
        }
        accountGl_tab.push(accountGL);
        //Prepare CurrencyAmount
        var currencyAmount = {


            "itemAccountNumber": itemNo.toString(),
            "currency": $.context.invoiceDetails.headerDetail.currency,
            "amount": items[i].amount,
            "baseAmount": "",
            "exchangeRate": $.context.invoiceDetails.headerDetail.exchangeRate
        };
        currencyAmount_tab.push(currencyAmount);
    }

    

    $.context.internal.validation.ERPValidationPayload = {
        "headerData": {
            "userName": $.context.invoiceDetails.headerDetail.initiator,
            "postingDate": $.context.invoiceDetails.headerDetail.postingDate,
            "documentDate": $.context.invoiceDetails.headerDetail.invoiceDate,
            "companyCode": $.context.invoiceDetails.headerDetail.companyCode,
            "docType": "KR",
            "reference": $.context.invoiceDetails.headerDetail.reference
        },
        "customerCD": customerCD,
        "accountPayable": accountPayable,
        "currencyAmount": currencyAmount_tab,
        "accountGL": accountGl_tab

    };
} else {
    //Check invoice payload if invoice is taxable invoice
    var taxableAmount = 0;
    var currencyAmount_tab = $.context.internal.taxCalculationResponse.currencyAmount;
    for (var i = 0; i < currencyAmount_tab.length; i++) {
        taxableAmount = taxableAmount + parseFloat(currencyAmount_tab[i].amount);
    }
    $.context.invoiceDetails.headerDetail.taxableAmount = taxableAmount;
    taxableAmount = taxableAmount * -1;

    var currencyAmount = {
        "itemAccountNumber": 1,
        "currency": $.context.invoiceDetails.headerDetail.currency,
        "amount": taxableAmount.toString(),
        "baseAmount": "0",
        "exchangeRate": $.context.invoiceDetails.headerDetail.exchangeRate
    };
    currencyAmount_tab.push(currencyAmount);
    
    var accountGL = $.context.internal.taxCalculationPayload.accountGL;
    $.context.internal.validation.ERPValidationPayload = {
        "headerData": $.context.internal.taxCalculationPayload.headerData,
        "customerCD": customerCD,
        "accountPayable": accountPayable,
        "currencyAmount": currencyAmount_tab,
        "accountGL": accountGL,
        "accountTax": $.context.internal.taxCalculationResponse.accountTax

    };
    for(var j = 0; j< currencyAmount_tab.length; j++){
        $.context.internal.validation.ERPValidationPayload.currencyAmount[j].exchangeRate =  $.context.invoiceDetails.headerDetail.exchangeRate;
    }
}