function isArray(arr) {
    return arr.constructor.toString().indexOf("Array") > -1;
}

//Preparing rework reason, if invoice validation failed from SAP ERP
var msg;
$.context.internal.validation.validationMessage = "";
$.context.internal.isERPValidated = true;
$.context.internal.reworkReason = [];
var result = $.context.internal.validation.ERPValidationResponse.return;
if (typeof result[0] !== 'undefined') {
    for (var i = 0; i < result.length; i++) {
        if (result[i].type == "E") {
            $.context.internal.isERPValidated = false;
            if (i > 0) {
                if ($.context.internal.validation.validationMessage === "") {
                    $.context.internal.validation.validationMessage = result[i].message + ". ";
                } else {
                    $.context.internal.validation.validationMessage = $.context.internal.validation.validationMessage + '\n';
                    $.context.internal.validation.validationMessage = $.context.internal.validation.validationMessage + result[i].message + ". ";
                }
                var msg = {
                    "message": result[i].message
                }

                $.context.internal.reworkReason.push(msg);
            }
        }
    }
} else {
    if (result.type === "E") {
        $.context.internal.isERPValidated = false;
    }
}
