//Preparing validation messages, if business rules validation failed
$.context.internal.isValidate = true;
var invoiceValResult = $.context.internal.validation.ruleValidationResult.Result;
for(var i=0; i<invoiceValResult.length;i++){
    if(invoiceValResult[i].Validation.IsValid == false){
        $.context.internal.isValidate = false;
        $.context.internal.validation.validationMessage = invoiceValResult[i].Validation.Message;
    }
}
