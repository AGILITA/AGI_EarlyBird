//Rules service id for item group determination
var ruleServiceId = "d6315eac4fb145c5b22a89edefc93e0d";
var ruleServiceRevision = "2011";
var headerDetails = $.context.invoiceDetails.headerDetail;
var invDate = headerDetails.invoiceDate.substring(0, 4)
            + "-" + headerDetails.invoiceDate.substring(4, 6)
            + "-" + headerDetails.invoiceDate.substring(6, 8);

//Preparing payload for item group determination            
$.context.internal.itemGroupPayload =
{
    "RuleServiceId": ruleServiceId,
    "RuleServiceRevision": ruleServiceRevision,
    "Vocabulary": [
        {
            "InvoiceHeaderDetails": {
                "Refrence": headerDetails.reference,
                "CompanyCode": headerDetails.companyCode,
                "InvoiceDate": invDate,
                "CurrencyKey": headerDetails.currency,
                "PaymentTerms": headerDetails.paymentTerm,
                "PaymentMethod": headerDetails.paymentMethod
            }
        }

    ]
}

